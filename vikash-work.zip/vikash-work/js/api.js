// JavaScript Document

	const ul = document.getElementById('wrapper-assignment'),
      url = 'https://rickandmortyapi.com/api/character/';

const createNode = (element) => { return document.createElement(element); }
const append = (parent, el) => { return parent.appendChild(el); }

fetch(url)
  .then((response) => { return response.json(); })
  .then( data => {
    let runners = data.results; 
    return runners.map( runner => { 
      let li = createNode('li'), 
          img = createNode('img'),
          span = createNode('span');
		h6 = createNode('h6');
		statusp = createNode('h5');
		species = createNode('h5');
		gender = createNode('h5');
		origin = createNode('h5');
		locationp = createNode('h5');
      img.src = runner.image;  
      span.innerHTML = `${runner.name}`; 
		statusp.innerHTML = `<span class='pull-left'>Status:</span> <span class='pull-right'>${runner.status}</span>`;
		species.innerHTML = `<span class='pull-left'>Species:</span> <span class='pull-right'>${runner.species}</span>`;
		gender.innerHTML = `<span class='pull-left'>Gender:</span> <span class='pull-right'>${runner.gender}</span>`;
		origin.innerHTML = `<span class='pull-left'>Origin:</span> <span class='pull-right'>${runner.origin.name}</span>`;
		locationp.innerHTML = `<span class='pull-left'>Last Location:</span> <span class='pull-right'>${runner.location.name}</span>`;
		h6.innerHTML = `<span class='pull-left'>id: ${runner.id}</span> <span class='pull-right'>Created: ${runner.created}</span>`;
      append(li, img); 
      append(li, span);
		append(li, h6);
		append(li, statusp);
		append(li, species);
		append(li, gender);
		append(li, origin);
		append(li, locationp);
      append(ul, li);
    });
  })
  .catch( error => { console.log(error); })
